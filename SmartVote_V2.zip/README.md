# SmartVote Version 2

A learning project for an electronic election system using:

- Node.js
- Express
- SQLite
- HTML/CSS/JavaScript
- Admin dashboard

## Features

### Voter
- Enter voter ID
- View candidates
- Vote once
- Vote is stored in SQLite
- A second vote is rejected

### Admin
- Basic authentication
- View total voters
- View votes cast
- View remaining voters
- View candidates
- View election results
- Add voters
- Add candidates

## Run locally

Install Node.js first.

Then open a terminal in this project folder:

```bash
npm install
npm start
```

Open:

```text
http://localhost:3000
```

Admin:

```text
http://localhost:3000/admin
```

Default development admin:

Username: `admin`

Password: `ChangeMe123!`

Before any real deployment, change the admin password using environment variables and replace the demo authentication with proper secure authentication.

## Database

When the server starts, it creates:

`smartvote.db`

Tables:

- voters
- candidates
- votes

## Important

This is an educational prototype. It is NOT suitable for a legally binding public election yet. A real election system needs strong authentication, encryption, access controls, audit logs, backup/recovery, privacy protections, independent security testing, and a carefully designed voting/identity separation model.
