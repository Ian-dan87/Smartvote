const express = require("express");
const path = require("path");
const Database = require("better-sqlite3");

const app = express();
const PORT = process.env.PORT || 3000;
const db = new Database("smartvote.db");

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

db.exec(`
CREATE TABLE IF NOT EXISTS voters (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  voter_id TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  has_voted INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS candidates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  position TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS votes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  voter_id INTEGER NOT NULL UNIQUE,
  candidate_id INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(voter_id) REFERENCES voters(id),
  FOREIGN KEY(candidate_id) REFERENCES candidates(id)
);
`);

const voterCount = db.prepare("SELECT COUNT(*) AS c FROM voters").get().c;
if (voterCount === 0) {
  const addVoter = db.prepare("INSERT INTO voters (voter_id, name) VALUES (?, ?)");
  const seedVoters = db.transaction(() => {
    [
      ["VOTER001", "Student One"],
      ["VOTER002", "Student Two"],
      ["VOTER003", "Student Three"],
      ["VOTER004", "Student Four"],
      ["VOTER005", "Student Five"]
    ].forEach(v => addVoter.run(...v));
  });
  seedVoters();
}

const candidateCount = db.prepare("SELECT COUNT(*) AS c FROM candidates").get().c;
if (candidateCount === 0) {
  const addCandidate = db.prepare(
    "INSERT INTO candidates (name, position) VALUES (?, ?)"
  );
  const seedCandidates = db.transaction(() => {
    [
      ["Ian Dancan", "President"],
      ["Brian Otieno", "President"],
      ["Kevin Ochieng", "President"]
    ].forEach(c => addCandidate.run(...c));
  });
  seedCandidates();
}

// Demo admin credentials for local development.
// Change these before deploying anywhere.
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || "admin";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "ChangeMe123!";

function adminRequired(req, res, next) {
  const auth = req.headers.authorization || "";
  if (!auth.startsWith("Basic ")) {
    res.set("WWW-Authenticate", 'Basic realm="SmartVote Admin"');
    return res.status(401).json({ error: "Admin login required" });
  }

  const decoded = Buffer.from(auth.slice(6), "base64").toString("utf8");
  const [username, password] = decoded.split(":");

  if (username !== ADMIN_USERNAME || password !== ADMIN_PASSWORD) {
    res.set("WWW-Authenticate", 'Basic realm="SmartVote Admin"');
    return res.status(401).json({ error: "Invalid admin credentials" });
  }

  next();
}

app.get("/api/candidates", (req, res) => {
  const candidates = db.prepare(
    "SELECT id, name, position FROM candidates ORDER BY position, id"
  ).all();
  res.json(candidates);
});

app.post("/api/vote", (req, res) => {
  const { voterId, candidateId } = req.body;

  if (!voterId || !candidateId) {
    return res.status(400).json({ error: "Voter ID and candidate are required." });
  }

  const voter = db.prepare(
    "SELECT * FROM voters WHERE voter_id = ?"
  ).get(voterId);

  if (!voter) {
    return res.status(404).json({ error: "Voter ID not found." });
  }

  if (voter.has_voted) {
    return res.status(409).json({ error: "This voter has already voted." });
  }

  const candidate = db.prepare(
    "SELECT * FROM candidates WHERE id = ?"
  ).get(candidateId);

  if (!candidate) {
    return res.status(404).json({ error: "Candidate not found." });
  }

  const castVote = db.transaction(() => {
    db.prepare(
      "INSERT INTO votes (voter_id, candidate_id) VALUES (?, ?)"
    ).run(voter.id, candidate.id);

    db.prepare(
      "UPDATE voters SET has_voted = 1 WHERE id = ?"
    ).run(voter.id);
  });

  try {
    castVote();
    res.json({ message: "Vote recorded successfully." });
  } catch (err) {
    res.status(500).json({ error: "Vote could not be recorded." });
  }
});

app.get("/api/admin/summary", adminRequired, (req, res) => {
  const voters = db.prepare("SELECT COUNT(*) AS c FROM voters").get().c;
  const voted = db.prepare(
    "SELECT COUNT(*) AS c FROM voters WHERE has_voted = 1"
  ).get().c;
  const candidates = db.prepare(
    "SELECT COUNT(*) AS c FROM candidates"
  ).get().c;

  res.json({
    voters,
    voted,
    remaining: voters - voted,
    candidates
  });
});

app.get("/api/admin/results", adminRequired, (req, res) => {
  const results = db.prepare(`
    SELECT
      c.id,
      c.name,
      c.position,
      COUNT(v.id) AS votes
    FROM candidates c
    LEFT JOIN votes v ON v.candidate_id = c.id
    GROUP BY c.id
    ORDER BY c.position, votes DESC, c.name
  `).all();

  res.json(results);
});

app.post("/api/admin/voters", adminRequired, (req, res) => {
  const { voterId, name } = req.body;

  if (!voterId || !name) {
    return res.status(400).json({ error: "Voter ID and name are required." });
  }

  try {
    db.prepare(
      "INSERT INTO voters (voter_id, name) VALUES (?, ?)"
    ).run(voterId.trim(), name.trim());

    res.status(201).json({ message: "Voter added." });
  } catch {
    res.status(409).json({ error: "That voter ID already exists." });
  }
});

app.post("/api/admin/candidates", adminRequired, (req, res) => {
  const { name, position } = req.body;

  if (!name || !position) {
    return res.status(400).json({ error: "Candidate name and position are required." });
  }

  db.prepare(
    "INSERT INTO candidates (name, position) VALUES (?, ?)"
  ).run(name.trim(), position.trim());

  res.status(201).json({ message: "Candidate added." });
});

app.get("/admin", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "admin.html"));
});

app.listen(PORT, () => {
  console.log(`SmartVote running at http://localhost:${PORT}`);
  console.log("Admin dashboard: http://localhost:" + PORT + "/admin");
});
